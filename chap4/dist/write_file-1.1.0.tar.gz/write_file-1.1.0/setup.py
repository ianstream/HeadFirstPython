from distutils.core import setup

setup(
    name = 'write_file',
    version = '1.1.0',
    py_modules = ['write_file'],
    author= 'ianstream',
    author_email = 'ianstream@gmail.com',
    url = '',
    description = '',
)