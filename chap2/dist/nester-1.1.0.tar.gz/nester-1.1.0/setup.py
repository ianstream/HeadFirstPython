from distutils.core import setup

setup(
    name = 'nester',
    version = '1.1.0',
    py_modules = ['nester'],
    author= 'ianstream',
    author_email = 'ianstream@gmail.com',
    url = '',
    description = 'A simple printer of nested lists from Head First Python',
)