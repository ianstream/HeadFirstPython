from distutils.core import setup

setup(
    name = 'file_nester',
    version = '1.1.0',
    py_modules = ['file_nester'],
    author= 'ianstream',
    author_email = 'ianstream@gmail.com',
    url = '',
    description = '',
)