from distutils.core import setup

setup(
    name = 'coach',
    version = '1.1.0',
    py_modules = ['coach'],
    author= 'ianstream',
    author_email = 'ianstream@gmail.com',
    url = '',
    description = '',
)